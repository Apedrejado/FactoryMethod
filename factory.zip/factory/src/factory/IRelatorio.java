package factory;

public interface IRelatorio {
	 void GerarRelatorio(String data);
	
}
